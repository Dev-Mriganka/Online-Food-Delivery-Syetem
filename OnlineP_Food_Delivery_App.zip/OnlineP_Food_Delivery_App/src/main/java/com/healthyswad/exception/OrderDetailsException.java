package com.healthyswad.exception;


@SuppressWarnings("serial")
public class OrderDetailsException extends Exception {
	
	
	public OrderDetailsException() {
		
	}
	public OrderDetailsException(String msg) {
		super(msg);
	}
}
