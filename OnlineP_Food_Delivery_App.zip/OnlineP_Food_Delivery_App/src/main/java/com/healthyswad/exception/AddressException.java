package com.healthyswad.exception;

@SuppressWarnings("serial")
public class AddressException extends Exception {

	public AddressException() {
		super();

	}

	public AddressException(String message) {
		super(message);

	}

}
