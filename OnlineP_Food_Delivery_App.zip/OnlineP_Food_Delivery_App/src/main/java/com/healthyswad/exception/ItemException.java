package com.healthyswad.exception;

@SuppressWarnings("serial")
public class ItemException extends Exception{
	
	public ItemException() {
		super();
	}
	
	public ItemException(String message) {
		super(message);
	}

}
