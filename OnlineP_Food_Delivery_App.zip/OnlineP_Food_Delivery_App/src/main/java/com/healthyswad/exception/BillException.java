package com.healthyswad.exception;


@SuppressWarnings("serial")
public class BillException extends Exception{
	
	

	public BillException() {
		// TODO Auto-generated constructor stub

		
		super();
	}
	
	public BillException(String message) {
		
		super(message);
	}
}