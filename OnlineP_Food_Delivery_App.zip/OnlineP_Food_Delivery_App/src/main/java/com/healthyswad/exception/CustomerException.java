package com.healthyswad.exception;

@SuppressWarnings("serial")
public class CustomerException extends Exception{

	public CustomerException() {
		super();
		
	}

	public CustomerException(String message) {
		super(message);
		
	}
	
	
	
}
