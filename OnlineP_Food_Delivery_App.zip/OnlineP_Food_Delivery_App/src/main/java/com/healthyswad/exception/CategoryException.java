package com.healthyswad.exception;

public class CategoryException extends Exception {
	
	public CategoryException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public CategoryException(String message) {
		super(message);
	}

}
