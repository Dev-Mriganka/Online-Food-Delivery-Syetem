package com.healthyswad.exception;

@SuppressWarnings("serial")
public class LoginException extends Exception{

	public LoginException() {
		
	}
	
	public LoginException(String message) {
		super(message);
	}
	
	
}
